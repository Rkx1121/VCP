import warnings
from matplotlib import MatplotlibDeprecationWarning
warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)

import matplotlib.ticker as mtick
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
from mindquantum.core.circuit import Circuit, UN
from mindquantum.core.gates import H, RZ, RX, Rzz
from mindquantum.core.operators import QubitOperator, Hamiltonian
from mindquantum.simulator import Simulator
from mindquantum.core.parameterresolver import ParameterResolver
from scipy.optimize import minimize
from vcp_solver import MinimumVertexCoverSolver  # 穷举
import csv

graph = nx.Graph()
# # The undirected graph with 10 vertices and 11 edges
graph.add_edges_from([(0, 2), (0, 5),(0, 7),
                      (2, 9), (6, 9),(7, 9),
                      (3,7),(4, 7),(3, 4),(3, 8),(3, 1)
                      ])
# nx.draw(graph, with_labels=True, font_weight='bold')
np.random.seed(42)

weights = {i: round(np.random.uniform(0, 1), 2) for i in graph.nodes}
print("顶点权值:",weights)
total_weight = sum(weights.values())
print("顶点总权值:",total_weight)
n_nodes = graph.number_of_nodes()
n_edges = graph.number_of_edges()
squared_sum = sum(weight**2 for weight in weights.values())
avg_s=squared_sum / n_nodes
avg_weight = total_weight / n_nodes
avg_degree = 2 * n_edges / n_nodes
print("顶点平均度:",avg_degree)
A = 1.5
solver = MinimumVertexCoverSolver(graph)
mvc = solver.brute_force_weighted(weights)
print("最小顶点覆盖:", mvc)
optimal_weight = sum(weights[i] for i in mvc)
print("最小顶点覆盖权值:", optimal_weight)


def build_cost_hamiltonian(graph, weights, A):
    ham = QubitOperator()
    for (i, j) in graph.edges:
        ham += QubitOperator(f'Z{i} Z{j}') * (A / 4)
    for i in graph.nodes:
        coeff = 0.5 * weights[i] - (A / 4) * graph.degree[i]
        ham += QubitOperator(f'Z{i}') * coeff
    return Hamiltonian(ham)


const_term = (A / 4) * n_edges + 0.5 * sum(weights.values())

def build_cost_layer(graph, weights, A, para):
    circ = Circuit()
    for (i, j) in graph.edges:
        para1 = ParameterResolver({para: A / 2})
        circ += Rzz(para1).on((j, i))
    for i in graph.nodes:
        coeff = 0.5 * weights[i] - (A / 4) * graph.degree[i]
        para2= ParameterResolver({para: coeff})
        circ += RZ(para2).on(i)
    circ.barrier()
    return circ
def build_mixer_layer(n_qubits, para):
    circ = Circuit()
    for i in range(n_qubits):
        para1 = ParameterResolver({para: 2 })
        circ += RX(para1).on(i)
    circ.barrier()
    return circ


p =9
k=4
def build_qaoa_ansatz(graph, weights, A, p):
    circ = Circuit()
    circ += UN(H, graph.nodes)
    for layer in range(p):
        circ += build_cost_layer(graph, weights, A, f'g{layer}')
        circ += build_mixer_layer(graph.number_of_nodes(), f'b{layer}')
    if p==1:
        circ.svg(width=1500).to_file("QAOA.svg")

    return circ


ham = build_cost_hamiltonian(graph, weights, A)
circ = build_qaoa_ansatz(graph, weights, A, p)
sim = Simulator("mqvector", circ.n_qubits)
grad_ops = sim.get_expectation_with_grad(ham, circ)


data = []
with open('data3/1_med.csv', mode='r', newline='') as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader)
    for row in csv_reader:
        data.append(row)

def get_parameters_for_p(p):
    if p < 2 or p > 9:
        raise ValueError("p值必须在 2 到 9 之间")

    for row in data:
        if int(row[0]) == p:
            g_values = [float(value) for value in row[1:1 + p]]
            b_values = [float(value) for value in row[1 + p:1 + 2*p]]
            return g_values, b_values

    raise ValueError(f"未找到对应p值为 {p} 的数据")

g_values, b_values = get_parameters_for_p(p)   # 获取参数
print(g_values,b_values)

r=(1/avg_weight)*np.arctan(1/(np.sqrt(avg_degree)-0.1*k))
# r=(1/avg_weight)*np.arctan(1 / np.sqrt(avg_degree - 1))
g_values_scaled = [val * r for val in g_values]

p0 = np.concatenate([g_values_scaled, b_values])
print(p0)


history = []
approx_ratios = []
step = 0

def objective(p):
    global step
    f, g = grad_ops(p)
    f = np.real(f)[0, 0] + const_term
    g = np.real(g)[0, 0, :]

    approx_ratio = (f - optimal_weight) / (total_weight - optimal_weight)
    history.append(f)
    approx_ratios.append(approx_ratio)
    step += 1
    if step % 10 == 0:
        print(f"Step {step}: Cover value = {f:.6f}, Approximation Ratio = {approx_ratio:.6f}")
    return f, g

# res = minimize(objective, p0, method='BFGS', jac=True)
res = minimize(objective, p0, method='BFGS', jac=True, options={'maxiter': 200, 'gtol': 1e-9})




plt.figure(figsize=(8,5))
plt.plot(approx_ratios, label='Approximation Ratio')
plt.xlabel("Optimization Step")
plt.ylabel("Approximation Ratio")
plt.title("QAOA Approximation Ratio Curve")
plt.legend()
plt.grid(True)
plt.show()

# 输出最优参数
final_params = dict(zip(circ.params_name, res.x))
print(f"Final Parameters: {final_params}")




