import warnings
from matplotlib import MatplotlibDeprecationWarning

warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)
import matplotlib.ticker as mtick
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
from mindquantum.core.circuit import Circuit, UN
from mindquantum.core.gates import H, RZ, RX, Rzz
from mindquantum.core.operators import QubitOperator, Hamiltonian
from mindquantum.simulator import Simulator
from mindquantum.core.parameterresolver import ParameterResolver
from scipy.optimize import minimize
from vcp_solver import MinimumVertexCoverSolver  # 穷举
import csv
import json


def build_cost_hamiltonian(graph, weights, A):
    ham = QubitOperator()
    for (i, j) in graph.edges:
        ham += QubitOperator(f'Z{i} Z{j}') * (A / 4)
    for i in graph.nodes:
        coeff = 0.5 * weights[i] - (A / 4) * graph.degree[i]
        ham += QubitOperator(f'Z{i}') * coeff
    return Hamiltonian(ham)


def build_cost_layer(graph, weights, A, para):
    circ = Circuit()
    for (i, j) in graph.edges:
        para1 = ParameterResolver({para: A / 2})
        circ += Rzz(para1).on((j, i))
    for i in graph.nodes:
        coeff = 0.5 * weights[i] - (A / 4) * graph.degree[i]
        para2 = ParameterResolver({para: coeff})
        circ += RZ(para2).on(i)
    circ.barrier()
    return circ


def build_mixer_layer(n_qubits, para):
    circ = Circuit()
    for i in range(n_qubits):
        para1 = ParameterResolver({para: 2})
        circ += RX(para1).on(i)
    circ.barrier()
    return circ


def build_qaoa_ansatz(graph, weights, A, p):
    circ = Circuit()
    circ += UN(H, graph.nodes)
    for layer in range(p):
        circ += build_cost_layer(graph, weights, A, f'g{layer}')
        circ += build_mixer_layer(graph.number_of_nodes(), f'b{layer}')
    if p == 1:
        circ.svg(width=1500).to_file("QAOA.svg")

    return circ


# 从 CSV 文件读取图的边列表
csv_file_path = 'graph3c.csv'  # 假设 CSV 文件的路径
Graphs = {}

with open(csv_file_path, mode='r') as csvfile:
    reader = csv.reader(csvfile)
    next(reader)  # 跳过表头

    for row in reader:
        graph_id = int(row[0])  # 获取图的编号
        edges = json.loads(row[1])  # 将边列表的字符串转为列表
        Graphs[graph_id] = edges  # 存储到字典中

# 计算图的平均度并写入 CSV 文件
output_csv_file = 'data3/op1.csv'
with open(output_csv_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(
        ['Graph ID', 'Average Degree', 'P Layer'] + [f'g{i}' for i in range(10)] + [f'b{i}' for i in range(10)])

    for i in range(132000,273192):
        graph = nx.Graph()
        try:
            # 尝试从 Graphs 中获取第 i 个键的边列表
            graph.add_edges_from(Graphs[i])
        except KeyError:
            # 如果 Graphs 中没有 i 这个键，跳过当前循环
            print(f"Key {i} not found in Graphs.")
            continue  # 继续下一个 i 的循环

        if graph.number_of_nodes() == 0:
            print(f"Graph {i} has no nodes, skipping...")
            continue  # 如果没有节点，跳过当前循环

        # 计算平均度并保留三位小数
        avg_degree = round(sum(dict(graph.degree()).values()) / graph.number_of_nodes(), 3)

        weights = {i: 1.0 for i in graph.nodes}
        total_weight = sum(weights.values())
        n_nodes = graph.number_of_nodes()
        n_edges = graph.number_of_edges()
        avg_weight = total_weight / n_nodes
        A = 1.5
        solver = MinimumVertexCoverSolver(graph)
        mvc = solver.brute_force_weighted(weights)
        optimal_weight = sum(weights[i] for i in mvc)

        const_term = (A / 4) * n_edges + 0.5 * sum(weights.values())

        for p in range(7, 10):
            ham = build_cost_hamiltonian(graph, weights, A)
            circ = build_qaoa_ansatz(graph, weights, A, p)
            sim = Simulator("mqvector", circ.n_qubits)
            grad_ops = sim.get_expectation_with_grad(ham, circ)
            rng = np.random.default_rng(42)
            p0 = rng.random(size=len(circ.params_name)) * np.pi * 2 - np.pi

            history = []
            approx_ratios = []
            step = 0


            def objective(p):
                global step
                f, g = grad_ops(p)
                f = np.real(f)[0, 0] + const_term
                g = np.real(g)[0, 0, :]

                approx_ratio = (f - optimal_weight) / (total_weight - optimal_weight)
                history.append(f)
                approx_ratios.append(approx_ratio)
                step += 1
                # if step % 10 == 0:
                #     print(i)
                    # print(f"Step {step}: Cover value = {f:.6f}, Approximation Ratio = {approx_ratio:.6f}")
                return f, g


            res = minimize(objective, p0, method='BFGS', jac=True)

            # 输出最优参数
            final_params = dict(zip(circ.params_name, res.x))

            # 将 g 系列和 b 系列参数分开并保留7位小数
            g_params = [round(final_params[f'g{i}'], 7) for i in range(p)]  # g0, g1, ...
            b_params = [round(final_params[f'b{i}'], 7) for i in range(p)]  # b0, b1, ...

            # 检查近似比是否小于0.1
            if approx_ratios[-1] < 0.1:
                # 写入数据到 CSV 文件
                with open(output_csv_file, mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([i, avg_degree, p] + g_params + b_params)






