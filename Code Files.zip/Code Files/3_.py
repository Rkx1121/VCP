import csv
import numpy as np

input_filename = 'graph.csv'
output_filename = '_tra.csv'

with open(input_filename, 'r', newline='') as csvfile, open(output_filename, 'w', newline='') as outfile:
    reader = csv.reader(csvfile)
    writer = csv.writer(outfile)

    header = next(reader)
    writer.writerow(header)

    for row in reader:

        d = float(row[1])
        p = int(row[2])

        g_values = [float(x) for x in row[3:3 + p]]

        scale = 1 / np.arctan(1 / np.sqrt(d - 1))

        scaled_data = [round(x * scale, 7) for x in g_values]

        row[3:3 + p] = scaled_data

        writer.writerow(row)
