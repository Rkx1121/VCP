import csv
import numpy as np


input_file_path = '_tra.csv'
output_file_path_data = '_p9.csv'
output_file_path_statistics = 'statistics.csv'

# 指定需要过滤的P Layer值
p_value = '9'

# 1. 从原始文件中筛选出 P Layer 值为 '9' 的数据并写入 _p9.csv
with open(input_file_path, mode='r', newline='', encoding='utf-8') as infile, open(output_file_path_data, mode='w',
                                                                                   newline='', encoding='utf-8') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)

    # 过滤并写入相同P Layer值的行
    for row in reader:
        if row[2] == p_value:  # 判断P Layer列是否为指定值
            writer.writerow(row[3:])  # 只写入P Layer后面的数据

# # 2. 从 _p2.csv 中计算最小值、中位数和最大值并写入到 statistics.csv
# 读取原始数据
data = []
with open(output_file_path_data, mode='r', newline='', encoding='utf-8') as infile:
    reader = csv.reader(infile)
    for row in reader:
        data.append([float(x) for x in row])  # 转换为浮动类型，以便计算统计量

# 检查每行的数据个数是否一致
row_lengths = [len(row) for row in data]
if len(set(row_lengths)) != 1:
    raise ValueError("数据行的长度不一致，请检查输入文件。")  # 抛出异常

# 获取每行数据的长度，并赋值给p
p = row_lengths[0] // 2  # 将每行数据的一半赋给p

# 初始化存放前p个数据和后p个数据的数组
first_half = []
second_half = []

# 遍历每一行，将前p个数据存放到first_half，后p个数据存放到second_half
for row in data:
    for i in range(p):  # 将前p个数据放入first_half
        first_half.append(row[i])
    for i in range(p, 2*p):  # 将后p个数据放入second_half
        second_half.append(row[i])

# 对first_half和second_half中的每个数据进行排序，并选取最小、中间、最大的p个
sorted_min_first_half = []
sorted_mid_first_half = []
sorted_max_first_half = []

sorted_min_second_half = []
sorted_mid_second_half = []
sorted_max_second_half = []

# 对每个数据块（前p和后p）进行排序并选取最小、中间、最大
sorted_first_half = sorted(first_half)
sorted_second_half = sorted(second_half)

k1=len(sorted_first_half)//2
k2=len(sorted_second_half)//2


# 选取最小的p个，中间的p个，最大的p个
sorted_min_first_half = sorted_first_half[:p]
sorted_mid_first_half = sorted_first_half[k1 : k1 + p]
sorted_max_first_half = sorted_first_half[-p:]

sorted_min_second_half = sorted_second_half[:p]
sorted_mid_second_half = sorted_second_half[k2 : k2 + p]
sorted_max_second_half = sorted_second_half[-p:]



# 将处理后的结果写入新的CSV文件
with open(output_file_path_statistics, mode='w', newline='', encoding='utf-8') as outfile:
    writer = csv.writer(outfile)
    writer.writerow(sorted_min_first_half + sorted_min_second_half)  # 最小的p个
    writer.writerow(sorted_mid_first_half + sorted_mid_second_half)  # 中间的p个
    writer.writerow(sorted_max_first_half + sorted_max_second_half)  # 最大的p个

print(f"数据处理完成，统计结果已保存到 {output_file_path_statistics}")
