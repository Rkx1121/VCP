import csv
import os


def read_graphs_from_file(file_path):
    graphs = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        graph_data = []

        for line in lines:
            if not line.strip() or line.startswith("Graph"):
                # 如果遇到 "Graph" 或空行，开始处理图数据
                if graph_data:
                    graphs.append(graph_data)
                    graph_data = []
                continue

            # 处理邻接矩阵的上三角部分
            graph_data.append(list(map(int, line.strip())))

        # 处理最后一个图的数据（没有空行结束）
        if graph_data:
            graphs.append(graph_data)
    return graphs


def convert_to_edge_list(graphs):
    edge_lists = []
    for graph_index, graph in enumerate(graphs):
        edges = []
        num_vertices = len(graph) + 1  # 图的顶点数 = 行数 + 1
        for i in range(num_vertices - 1):  # 遍历每个顶点
            for j in range(i + 1, num_vertices):  # 遍历其后面的顶点
                if graph[i][j - i - 1] == 1:  # 如果存在边
                    edges.append((i, j))
        edge_lists.append(edges)
    return edge_lists

def save_edges_to_csv(edge_lists, output_file_path, start_index):
    with open(output_file_path, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for edges in edge_lists:
            # 将边从元组列表改为嵌套列表形式，然后转为字符串
            edge_list = [[edge[0], edge[1]] for edge in edges]
            edge_str = str(edge_list)  # 直接用str()函数得到字符串格式
            writer.writerow([start_index, edge_str])
            start_index += 1
    return start_index



def process_multiple_files(input_directory, output_file_path):
    # 获取当前 CSV 文件中的最后一个图的ID
    if os.path.exists(output_file_path):
        with open(output_file_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            last_row = list(reader)[-1]  # 读取最后一行
            start_index = int(last_row[0]) + 1 if last_row else 1
    else:
        start_index = 1  # 如果 CSV 文件不存在，则从1开始

    # 遍历文件夹中的所有txt文件
    for filename in os.listdir(input_directory):
        if filename.endswith(".txt"):
            input_file_path = os.path.join(input_directory, filename)

            # 处理单个文件
            graphs = read_graphs_from_file(input_file_path)
            edge_lists = convert_to_edge_list(graphs)
            start_index = save_edges_to_csv(edge_lists, output_file_path, start_index)
            print(f"Processed {filename} -> {output_file_path}")


# 输入文件夹路径和输出文件路径
input_directory = 'Graphs'  # 输入文件夹路径
output_file_path = 'graph.csv'  # 输出CSV文件路径

process_multiple_files(input_directory, output_file_path)
