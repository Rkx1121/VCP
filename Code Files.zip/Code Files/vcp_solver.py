import networkx as nx
import itertools

class MinimumVertexCoverSolver:
    def __init__(self, graph: nx.Graph):
        self.graph = graph

    def _is_vertex_cover(self, vertex_set):
        """判断一个顶点集合是否为图的顶点覆盖"""
        for u, v in self.graph.edges():
            if u not in vertex_set and v not in vertex_set:
                return False
        return True

    def brute_force(self):
        """使用穷举法求解最小顶点覆盖（最小顶点数）"""
        nodes = list(self.graph.nodes())
        n = len(nodes)

        for k in range(1, n + 1):
            for subset in itertools.combinations(nodes, k):
                if self._is_vertex_cover(subset):
                    return set(subset)
        return set()

    def brute_force_weighted(self, weights: dict):
        """
        使用穷举法求解加权最小顶点覆盖
        参数:
            weights: dict，形如 {node: weight, ...}
        返回:
            最小权重的顶点覆盖集
        """
        nodes = list(self.graph.nodes())
        best_cover = set()
        min_weight = float('inf')

        for k in range(1, len(nodes) + 1):
            for subset in itertools.combinations(nodes, k):
                if self._is_vertex_cover(subset):
                    total_weight = sum(weights.get(node, 1) for node in subset)
                    if total_weight < min_weight:
                        min_weight = total_weight
                        best_cover = set(subset)

        return best_cover
